from random import*

class Pokemon:
    def __init__(self,nom,vie,attaque,defense,liste_attaques,état):
        self.n=nom
        self.hp=vie
        self.at=attaque
        self.defe=defense
        self.lattaque=liste_attaques
        self.etat=état      
    
    def getNom(self):
        return self.n
    
    def getVie(self):
        return round (self.hp,0)
    
    def getAttaque(self):
        return self.at
    
    def getDefense(self):
        return self.defe
    
    def getEtat(self):
        return self.etat
    
    def getListe_attaque(self):
        return self.lattaque[0:len(self.lattaque)]
       
    def setEtat(self,e):
        self.etat=e
        
    def downVie(self,bhp):
        self.hp-=bhp
        
    def downAttaque(self,Batt):
        self.at-=Batt
    
    def downDefense(self,Bdef):
        self.defe-=Bdef
        
    def upVie(self,Uvie):
        self.hp+=Uvie
        
    def upAttaque(self,Uatt):
        self.at+=Uatt
        
    def upDefense(self,Udef):
        self.defe+=Udef
        
    def estMort(self):
        if self.hp!=0:
            return False
        else:
            return True
        
    def choix_attaque(self):
        for i in range(len(self.lattaque)):
            print(i+1,":",self.lattaque[i])
        self.choix=int(input("Quelle est ta reponse?\n"))
        return self.choix      
        
"""
_______________________________________________________________________________________________________________________________________________________________________
"""        
P1=Pokemon("Pikachu",110,20,20,[["Charge",20],["éclair",30],["Cage eclair","Paralysie"],["Charge-éclair",35]],"Normal")
P2=Pokemon("Raichu",120,25,30,[["Coup de Boule",20],["éclair impérial",35],["Cage eclair","Paralysie"],["Charge-éclair",25]],"Normal")
P3=Pokemon("Demoloss",110,20,25,[["Griffe",20],["lance-flamme",35],["Feu Follet","Brulure"],["Morsure",25]],"Normal")
P4=Pokemon("Mewtwo",150,35,40,[["Boule psycko",40],["Psy",20],["Intimidation","Paralysie"],["Morsure",25]],"Normal")
P5=Pokemon("Dracaufeu",140,30,25,[["Griffe",20],["lance-flamme",35],["Flamèche","Brulure"],["Morsure",25]],"Normal")
P6=Pokemon("Arcanin",150,20,25,[["Griffe",20],["Croc-feu",30],["Pied Bruleur","Brulure"],["Feu sacré",40]],"Normal")
P7=Pokemon("Mew",170,40,35,[["Piqûre Psy",50],["Piratage de Génome",20],["Voyance","Parlysie"],["Psyko",25]],"Normal")
P8=Pokemon("Ectoplasma",155,30,30,[["Ball'Ombre",45],["Eclat Spectral",25],["Etonnement","Brulure"],["Griffe Ombre",25]],"Normal")
P9=Pokemon("Bullbizare",180,15,40,[["Bullet Seed",30],["Tailblaze",20],["Intimidation","Dodo"],["Lance-Soleil",40]],"Normal")
P10=Pokemon("Leviator",130,35,35,[["Aqua-Jet",35],["Draco-Queue",25],["Intimidation","Paralysie"],["Bulles d'O",35]],"Normal")
P11=Pokemon("Dodrio",110,25,30,[["Bélier",30],["Coupe",35],["Champ-elct","Paralysie"],["Acrobatie",40]],"Normal")
P12=Pokemon("Excelangue",180,15,40,[["Damoclès",40],["Effort",35],["Lèche","Confus"],["Façade",25]],"Normal")
P13=Pokemon("Feuillajou",110,20,25,[["Bullet Seed",30],["Tailblaze",20],["Intimidation","Confus"],["Charge",20]],"Normal")
P14=Pokemon("Fluvetin",90,15,20,[["Canon Floral",20],["Rayon Lune",50],["Fairy Lock","Paralysie"],["Pouvoir Lunaire",40]],"Normal")
P15=Pokemon("Tortank", 150, 30, 35, [["Hydrocanon", 40], ["Cascade", 30], ["Torgnoles", "Dodo"], ["Laser Glace", 35]], "Normal")
P16=Pokemon("Florizarre", 140, 25, 30, [["Tranch'Herbe", 25], ["Fouet Lianes", 30], ["Poudre Dodo", "Dodo"], ["Lance-Soleil", 35]], "Normal")
P17=Pokemon("Empiflor", 145, 25, 35, [["Morsure", 25], ["Bélier", 30], ["Bomb", "Poison"], ["Bomb-Beurk", 40]], "Normal")
P18=Pokemon("Alakazam", 130, 25, 20, [["Psyko", 30], ["Onde Folie", 25], ["Voyance", "Confus"], ["Machination", 35]], "Normal")
P19=Pokemon("Ronflex", 160, 40, 40, [["Charge", 20], ["Groz'Yeux", 25], ["Roupillon", "Dodo"], ["Léchouille", 30]], "Normal")
P20=Pokemon("Leveinard", 130, 20, 35, [["Éclat Magique", 25], ["Repos", 35], ["Poudre Dodo", "Dodo"], ["Vœu", 30]], "Normal")
P21=Pokemon("Flagadoss", 140, 25, 30, [["Éclat Magique", 25], ["Hydrocanon", 40], ["Étincelle", "Paralysie"], ["Amnésie", 35]], "Normal")
P22=Pokemon("Aeromite", 150, 30, 25, [["Vive-Attaque", 30], ["Tornade", 25], ["Vampirisme", "Poison"], ["Piqué", 35]], "Normal")
P23=Pokemon("Magicarp", 160, 35, 40, [["Hydrocanon", 40], ["Aqua-Jet", 35], ["Vague à l'âme", "Confus"], ["Lance-Soleil", 30]], "Normal")
P24=Pokemon("Noadkoko", 140, 25, 30, [["Tranche", 25], ["Psyko", 30], ["Étincelle", "Paralysie"], ["Bomb-Beurk", 35]], "Normal")
P25=Pokemon("Cloyster", 150, 30, 25, [["Charge", 20], ["Pics Toxik", 35], ["Laser Glace", "Brulure"], ["Repli", 30]], "Normal")
P26=Pokemon("Exagide", 155, 35, 40, [["Éclat Magique", 30], ["Tranch'Herbe", 35], ["Fermeté", "Confus"], ["Garde Large", 25]], "Normal")
P27=Pokemon("Nymphali", 140, 25, 30, [["Charge", 20], ["Poudre Dodo", 30], ["Vive-Attaque", "Paralysie"], ["Croissance", 35]], "Normal")
P28=Pokemon("Amphinobi", 130, 30, 25, [["Cascade", 30], ["Hydrocanon", 40], ["Feinte", "Paralysie"], ["Éboulement", 35]], "Normal")
P29=Pokemon("Ptyranidur", 160, 35, 40, [["Draco-Queue", 35], ["Mâchouille", 30], ["Jet de Pierre", "Paralysie"], ["Gros Yeux", 25]], "Normal")
P30=Pokemon("Triopikeur", 140, 25, 30, [["Griffe", 25], ["Tunnelier", 30], ["Coud'Boue", "Confus"], ["Jet-Pierres", 35]], "Normal")
P31=Pokemon("Papilusion", 130, 20, 25, [["Poudre Dodo", 25], ["Papillodanse", 30], ["Éclat Magique", "Paralysie"], ["Garde Large", 35]], "Normal")
P32=Pokemon("Drattak", 150, 35, 30, [["Lance-Flamme", 35], ["Draco-Météore", 40], ["Ailes d'Acier", "Paralysie"], ["Vive-Attaque", 30]], "Normal")
P33=Pokemon("Gardevoir", 140, 25, 25, [["Psyko", 30], ["Éclat Magique", 25], ["Choc Psy", "Confus"], ["Vœu", 35]], "Normal")
P34=Pokemon("Steelix", 160, 30, 40, [["Jet de Pierre", 35], ["Mâchouille", 30], ["Gyroball", "Paralysie"], ["Tomberoche", 25]], "Normal")
P35=Pokemon("Jirachi", 170, 40, 35, [["Météores", 40], ["Vœu", 35], ["Gyroballe", "Paralysie"], ["Psyko", 30]], "Normal")
P36=Pokemon("Absol", 140, 30, 25, [["Tranche", 25], ["Ailes d'Acier", 30], ["Morsure", "Paralysie"], ["Vibrobscur", 35]], "Normal")
P37=Pokemon("Gallame", 150, 35, 30, [["Psyko", 30], ["Lame-Feuille", 35], ["Choc Psy", "Confus"], ["Vœu", 25]], "Normal")
P38=Pokemon("Pingoléon", 160, 35, 40, [["Hydrocanon", 40], ["Lance-Flamme", 35], ["Cage-Éclair", "Confus"], ["Plaquage", 30]], "Normal")
P39=Pokemon("Mammochon", 150, 30, 35, [["Lance-Flamme", 35], ["Blizzard", 40], ["Glace Éternelle", "Paralysie"], ["Morsure", 30]], "Normal")
P40=Pokemon("Carchacrok", 160, 40, 35, [["Crocs Feu", 35], ["Laser Glace", 30], ["Séisme", "Confus"], ["Danse Draco", 25]], "Normal")
P41=Pokemon("Démétéros", 170, 40, 35, [["Séisme", 40], ["Piqué", 35], ["Lance-Flammes", "Brulure"], ["Mach Punch", 30]], "Normal")
P42=Pokemon("Boréas", 140, 30, 25, [["Vent Violent", 30], ["Laser Glace", 25], ["Tornade", "Confus"], ["Rapace", 35]], "Normal")
P43=Pokemon("Noctali", 155, 35, 40, [["Éclat Magique", 30], ["Tranch'Herbe", 35], ["Fermeté", "Confus"], ["Garde Large", 25]], "Normal")
P44=Pokemon("Goinfrex", 140, 25, 30, [["Charge", 20], ["Poudre Dodo", 30], ["Vive-Attaque", "Paralysie"], ["Croissance", 35]], "Normal")
P45=Pokemon("Psykokwak", 130, 30, 25, [["Cascade", 30], ["Hydrocanon", 40], ["Feinte", "Confus"], ["Éboulement", 35]], "Normal")
P46=Pokemon("Lougaroc", 160, 35, 40, [["Draco-Queue", 35], ["Mâchouille", 30], ["Jet de Pierre", "Paralysie"], ["Gros Yeux", 25]], "Normal")
P47=Pokemon("Topikeur", 140, 25, 30, [["Griffe", 25], ["Tunnelier", 30], ["Coud'Boue", "Confus"], ["Jet-Pierres", 35]], "Normal")
P48=Pokemon("Métamorph", 130, 20, 20, [["Morphing", 30], ["Bélier", 25], ["Cage-Éclair", "Paralysie"], ["Éboulement", 40]], "Normal")
P49=Pokemon("Meloetta", 150, 30, 30, [["Chant Canon", 25], ["Vent Glace", 35], ["Force Cosmik", "Poison"], ["Choc Mental", 30]], "Normal")
P50=Pokemon("Rattatac", 140, 35, 25, [["Canon Griffe", 30], ["Lance-Flamme", 40], ["Vibrobscur", "Confus"], ["Chargeur", 25]], "Normal")
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
P51 = Pokemon("Givrali", 140, 25, 30, [["Éclat Magique", 25], ["Blizzard", 30], ["Voile de Neige", "Confus"], ["Danse Glace", 35]], "Normal")
P52 = Pokemon("Mimiqui", 145, 30, 25, [["Ombre Nocturne", 30], ["Feinte", 35], ["Dévorêve", "Paralysie"], ["Mimique", 25]], "Normal")
P53 = Pokemon("Brasegali", 150, 35, 30, [["Pied Brûleur", 35], ["Poing de Feu", 40], ["Lame de Roc", "Brulure"], ["Mach Punch", 30]], "Normal")
P54 = Pokemon("Méga-Ectoplasma", 155, 30, 35, [["Ball'Ombre", 35], ["Hypnose", 40], ["Vampirisme", "Paralysie"], ["Psyko", 30]], "Normal")
P55 = Pokemon("Galopa", 160, 35, 40, [["Frappe Psy", 40], ["Coup de Boule", 35], ["Grimace", "Confus"], ["Morsure", 30]], "Normal")
P56 = Pokemon("Méga-Flagadoss", 140, 25, 30, [["Éclat Magique", 25], ["Hydrocanon", 40], ["Étincelle", "Paralysie"], ["Amnésie", 35]], "Normal")
P57 = Pokemon("Méga-Florizarre", 170, 40, 35, [["Tranch'Herbe", 35], ["Lance-Soleil", 40], ["Éboulement", "Brulure"], ["Vampigraine", 30]], "Normal")
P58 = Pokemon("Pyroli", 150, 35, 30, [["Lance-Flamme", 30], ["Déflagration", 35], ["Danse Flamme", "Brulure"], ["Brouillard", 25]], "Normal")
P59 = Pokemon("Mew", 165, 40, 40, [["Piqûre Psy", 45], ["Piratage de Génome", 30], ["Voyance", "Parlysie"], ["Psyko", 35]], "Normal")
P60 = Pokemon("Lucario", 160, 35, 35, [["Aurasphère", 40], ["Close Combat", 35], ["Rengorgement", "Confus"], ["Vitesse Extrême", 30]], "Normal")
P61 = Pokemon("Motisma", 155, 30, 35, [["Tonnerre", 35], ["Éclat Magique", 30], ["Choc Mental", "Paralysie"], ["Vibrobscur", 25]], "Normal")
P62 = Pokemon("Palkia", 170, 40, 35, [["Spacial Rend", 40], ["Dracochoc", 35], ["Gyroballe", "Paralysie"], ["Laser Glace", 30]], "Normal")
P63 = Pokemon("Dialga", 165, 35, 40, [["Dracochoc", 35], ["Dracogriffe", 40], ["Choc Psy", "Confus"], ["Surf", 30]], "Normal")
P64 = Pokemon("Carchacrok", 160, 40, 35, [["Séisme", 40], ["Laser Glace", 35], ["Danse Draco", "Confus"], ["Colère", 25]], "Normal")
P65 = Pokemon("Drattak", 165, 35, 40, [["Tranche", 35], ["Lame d'Air", 40], ["Étincelle", "Paralysie"], ["Tomberoche", 30]], "Normal")
P66 = Pokemon("Noctunoir", 160, 35, 40, [["Ombre Nocturne", 40], ["Éclat Magique", 35], ["Morsure", "Confus"], ["Aboiement", 30]], "Normal")
P67 = Pokemon("Créhelf", 170, 40, 35, [["Psyko", 40], ["Éclat Magique", 35], ["Choc Psy", "Confus"], ["Vœu", 30]], "Normal")
P68 = Pokemon("Créfollet", 165, 35, 40, [["Feu Follet", 40], ["Psyko", 35], ["Choc Mental", "Confus"], ["Vœu", 30]], "Normal")
P69 = Pokemon("Créfadet", 160, 30, 35, [["Ombre Portée", 35], ["Ball'Ombre", 30], ["Feinte", "Paralysie"], ["Morsure", 25]], "Normal")
P70 = Pokemon("Darkrai", 175, 35, 40, [["Croc de Mort", 40], ["Tranch'Herbe", 35], ["Cauchemar", "Confus"], ["Ombre Nocturne", 30]], "Normal")
P71 = Pokemon("Genesect", 160, 35, 40, [["Piqûre", 40], ["Laser Glace", 35], ["Rayon Chargé", "Paralysie"], ["Techno Buster", 30]], "Normal")
P72 = Pokemon("Victini", 175, 40, 35, [["Vœu", 35], ["Psyko", 40], ["Séisme", "Paralysie"], ["Exploforce", 30]], "Normal")
P73 = Pokemon("Kyogre", 180, 40, 40, [["Hydrocanon", 40], ["Surf", 40], ["Glace Éternelle", "Brulure"], ["Danse Pluie", 35]], "Normal")
P74 = Pokemon("Groudon", 180, 40, 40, [["Séisme", 40], ["Éruption", 40], ["Glace Éternelle", "Paralysie"], ["Danse Soleil", 35]], "Normal")
P75 = Pokemon("Rayquaza", 185, 40, 40, [["Draco-Choc", 40], ["Vitesse Extrême", 40], ["Giga Impact", "Confus"], ["Colère", 35]], "Normal")
P76 = Pokemon("Deoxys", 170, 35, 40, [["Psyko", 40], ["Charge", 35], ["Météores", "Paralysie"], ["Morsure", 30]], "Normal")
P77 = Pokemon("Arceus", 190, 40, 40, [["Jugement", 45], ["Psyko", 40], ["Séisme", "Confus"], ["Blizzard", 35]], "Normal")
P78 = Pokemon("Dialga", 180, 40, 40, [["Dracochoc", 40], ["Éclat Magique", 40], ["Choc Psy", "Paralysie"], ["Surf", 35]], "Normal")
P79 = Pokemon("Palkia", 180, 40, 40, [["Spacial Rend", 40], ["Surf", 40], ["Gyroballe", "Paralysie"], ["Laser Glace", 35]], "Normal")
P80 = Pokemon("Giratina", 185, 40, 40, [["Ombre Portée", 40], ["Lame d'Air", 40], ["Gyroball", "Confus"], ["Draco Météore", 35]], "Normal")
P81 = Pokemon("Togekiss", 155, 30, 35, [["Vent Féérique", 35], ["Aurasphère", 30], ["Éclat Magique", "Paralysie"], ["Garde Large", 25]], "Normal")
P82 = Pokemon("Lucario", 160, 35, 35, [["Aurasphère", 40], ["Close Combat", 35], ["Rengorgement", "Confus"], ["Vitesse Extrême", 30]], "Normal")
P83 = Pokemon("Porygon-Z", 150, 30, 30, [["Triplattaque", 35], ["Psyko", 30], ["Choc Mental", "Paralysie"], ["Conversion", 25]], "Normal")
P84 = Pokemon("Gallame", 155, 35, 30, [["Psyko", 30], ["Lame-Feuille", 35], ["Choc Psy", "Confus"], ["Vœu", 25]], "Normal")
P85 = Pokemon("Leuphorie", 160, 25, 40, [["Éclat Magique", 30], ["Garde Large", 25], ["Météores", "Confus"], ["Vœu", 35]], "Normal")
P86 = Pokemon("Crefollet", 155, 30, 35, [["Feu Follet", 35], ["Psyko", 30], ["Choc Mental", "Confus"], ["Vœu", 25]], "Normal")
P87 = Pokemon("Noctunoir", 165, 35, 40, [["Ombre Nocturne", 40], ["Éclat Magique", 35], ["Morsure", "Confus"], ["Aboiement", 30]], "Normal")
P88 = Pokemon("Moufflair", 150, 30, 30, [["Laser Glace", 35], ["Éclats-Glace", 30], ["Grimace", "Paralysie"], ["Ébullition", 25]], "Normal")
P89 = Pokemon("Pharamp", 160, 35, 40, [["Éclair", 40], ["Cage-Éclair", 35], ["Étincelle", "Paralysie"], ["Abri", 30]], "Normal")
P90 = Pokemon("Tarpaud", 155, 30, 35, [["Hydrocanon", 35], ["Ébullition", 30], ["Grimace", "Confus"], ["Blizzard", 25]], "Normal")
P91 = Pokemon("Libégon", 160, 35, 40, [["Dracogriffe", 40], ["Ailes d'Acier", 35], ["Danse Draco", "Paralysie"], ["Tomberoche", 30]], "Normal")
P92 = Pokemon("Dracolosse", 165, 35, 40, [["Dracogriffe", 40], ["Ailes d'Acier", 35], ["Colère", "Confus"], ["Draco-Choc", 30]], "Normal")
P93 = Pokemon("Électhor", 170, 40, 35, [["Éclair", 40], ["Cage-Éclair", 35], ["Étincelle", "Paralysie"], ["Laser Glace", 30]], "Normal")
P94 = Pokemon("Sulfura", 170, 40, 35, [["Flammèche", 40], ["Canicule", 35], ["Danse-Flamme", "Brulure"], ["Ailes d'Acier", 30]], "Normal")
P95 = Pokemon("Artikodin", 170, 35, 40, [["Vent Glace", 40], ["Blizzard", 35], ["Glace Éternelle", "Paralysie"], ["Lance-Flammes", 30]], "Normal")
P96 = Pokemon("Mewtwo", 175, 40, 40, [["Boule Psycko", 40], ["Psyko", 35], ["Intimidation", "Paralysie"], ["Morsure", 30]], "Normal")
P97 = Pokemon("Groudon", 180, 40, 40, [["Séisme", 40], ["Éruption", 40], ["Glace Éternelle", "Paralysie"], ["Danse Soleil", 35]], "Normal")
P98 = Pokemon("Kyogre", 180, 40, 40, [["Hydrocanon", 40], ["Surf", 40], ["Glace Éternelle", "Brulure"], ["Danse Pluie", 35]], "Normal")
P99 = Pokemon("Rayquaza", 185, 40, 40, [["Draco-Choc", 40], ["Vitesse Extrême", 40], ["Giga Impact", "Confus"], ["Colère", 35]], "Normal")
P100 = Pokemon("Darkrai", 180, 35, 40, [["Ombre Nocturne", 40], ["Feinte", 35], ["Cauchemar", "Confus"], ["Éboulement", 30]], "Normal")

"""
__________________________________________________________________________________________________________________________________________________________________________________
"""
class Combat:
    def __init__(self,joueur="1",ennemi="2",tour=1):
        self.j=joueur
        self.e=ennemi
        self.tour=tour
        self.PAttaque=1
        self.PAttaqueE=1
        
    def getTour(self):
        return self.tour
    
    def getPokemonJoueur (self):
        return self.j.getNom()
    
    def getPokemonEnnemi(self):
        return self.e.getNom()
    
    def upTour(self):
        self.tour+=1
        return self.tour
    
    def activationEtatJ(self):
        from random import randint
        x=randint(1,2)
        if self.j.etat=="Brulure":
            self.j.hp-=10/self.j.defe
            print(self.j.getNom(),"est brulé")
            
        if self.j.etat=="Paralysie":
            print(self.j.getNom(),"est paralysé, il a une chance sur deux d'attaque")
            if x==2:
                self.PAttaque=x
            if x==1:
                self.e.setEtat("Normal")
            
    def activationEtatE(self):
        from random import randint
        x=randint(1,2)
        if self.e.etat=="Brulure":
            print(self.e.getNom(),"est brulé")
            self.e.hp-=5
            return self.e.hp
        if self.e.etat=="Paralysie":
            print(self.e.getNom(),"est paralysé, il a une chance sur deux d'attaquer")
            if x==2:
                self.PAttaqueE=x
            if x==1:
                self.e.setEtat("Normal")
                   
    def attaque(self):
        s=self.j.choix_attaque()
        if self.PAttaque==1:
            if s==1:
                l=self.j.lattaque[0]
                self.e.hp-=l[1]+self.j.at-self.e.defe
                
            elif s==2:
                l=self.j.lattaque[1]
                self.e.hp-=l[1]+self.j.at-self.e.defe
                
            elif s==3:
                l=self.j.lattaque[2]
                self.e.etat=l[1]
                
            elif s==4:
                l=self.j.lattaque[3]
                self.e.hp-=l[1]+self.j.at-self.e.defe
            else:
                self.attaque()
            self.PAttaqueJ=1
        if self.PAttaque==2:
            print( "Paralysé, il ne peut pas attaquer")
            self.PAttaque=1
            self.j.setEtat("Normal")
        
        
    def attaqueE(self):
        from random import randint
        a=randint(1,4)
        if self.PAttaqueE==1:
            if a==1:
                l=self.e.lattaque[0]
                self.j.hp-=l[1]+self.e.at-self.j.defe
                print( "L'attaque lancer par l'énnemi est :", l[0])
            if a==2:
                l=self.e.lattaque[1]
                self.j.hp-=l[1]+self.e.at-self.j.defe
                print( "L'attaque lancer par l'énnemi est :", l[0])
            if a==3:
                l=self.e.lattaque[2]
                self.j.etat=l[1]
                print( "L'attaque lancer par l'énnemi est :", l[0])
                return self.j.etat
            if a==4:
                l=self.e.lattaque[3]
                self.j.hp-=l[1]+self.e.at-self.j.defe
                return ("L'attaque lancer par l'énnemi est :", l[0])
            self.PAttaqueE=1
            
        if self.PAttaqueE==2:
            print( "Paralysé, il ne peut pas attaquer")
            self.PAttaqueE=1
            self.e.setEtat("Normal")
"""
_______________________________________________________________________________________________________________________________________________________________________
"""            
class Jeu:
    def __init__(self,v=0,d=0,c=0):
        self.Lp=[P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37,
                 P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48,P49,P50,P51,P52,P53,P54,P55,P56,P57,P58,P59,P60,P61,P62,P63,P64,P65,P66,P67,P68,P69,P70,P71,P72,
                 P73,P74,P75,P76,P77,P78,P79,P80,P81,P82,P83,P84,P85,P86,P87,P88,P89,P90,P91,P92,P93,P94,P95,P96,P97,P98,P99,P100]
        self.v=v
        self.d=d
        self.c=c
        
        
        
    def getVictoire(self):
        return self.v
    
    def getDefaite(self):
        return self.d
    
    def getCombat(self):
        return self.c
    
    def setVictoire(self):
        self.v+=1
        
    def setDefaite(self):
        self.d+=1
        
    def downDefaite(self):
        self.d-=self.d
    
    def downVictoire(self):
        self.v-=self.v
        
        
    def setCombat(self):
        self.c+=1
        
    def aleatoire(self):
        from random import randint
        r=randint(1,len(self.Lp))
        return self.Lp[r-1].getNom()
    
    def rencontreP(self):
        from random import randint
        from time import sleep
        self.a=randint(1,len(self.Lp))
        pe=0
        print("_______________________________________________________________________________")
        print("Vous vous baladez dans Valenciennes.")
        sleep(1)
        print("Oh!!!")
        sleep(1)
        print("Il y a un",self.Lp[self.a-1].getNom(),"!!")
        sleep(1)
        reponse=input("Voulez-vous le capturer?\n")
        if reponse=="oui":
            if pe!=1:
                pe=randint(1,3)
                if pe==2:
                    print("Il est sorti de la pokéball")
                    pa=randint(1,2)
                    if pa==1:
                        sleep(1)
                        print("Vous relancez une pokéball")
                        sleep(1)
                        print("Vous l'avez capturé!")
                        pe=0
                        self.p=self.a
                        self.pe=self.a
                        
                    if pa==2:
                        print("Il s'est enfuit")
                        sleep(1)
                        pe=0
                        self.rencontreP()
                if pe==3:
                    print("Il s'est enfuit")
                    pe=0
                    sleep(1)
                    self.rencontreP()
            if pe==1:
                print("Vous l'avez capturé")
                self.p=self.a
                self.pe=self.a
        if reponse=="non":
            print("Vous repartez")
            sleep(1)
            self.rencontreP()
                
    def choixE(self):
        from random import randint
        if self.pe==self.a:
            self.pe=randint(1,len(self.Lp))
            self.choixE()
    
    def Tour(self):
        from time import sleep
        a=Combat(self.Lp[self.p-1],self.Lp[self.pe-1])
        print ("Le pokémon adverse est :",self.Lp[self.pe-1].getNom())
        while self.Lp[self.p-1].getVie()>0 and self.Lp[self.pe-1].getVie()>0:
            print("_______________________________________________________________________________")
            print("Tour :",a.getTour(),"\nA ton tour!")
            sleep(1)
            print("Il te reste:",self.Lp[self.p-1].getVie(),"PV")
            sleep(2)
            a.activationEtatJ()
            print("Il reste ",self.Lp[self.pe-1].getVie(),"PV a ton adversaire")
            sleep(1.5)
            print("Choisie ton attaque:")
            sleep(1)
            a.attaque()
            a.upTour()
            sleep(1)
            self.PAttaque=1
            if self.Lp[self.pe-1].getVie()>0:
                print("_______________________________________________________________________________")
                print("Tour :",a.getTour(),"\nAu tour de l'adversaire!")
                sleep(1)
                a.activationEtatE()
                sleep(1)
                a.attaqueE()
                sleep(1)
                a.upTour()
                self.PAttaqueE=1
                
"""
_______________________________________________________________________________________________________________________________________________________________________
"""