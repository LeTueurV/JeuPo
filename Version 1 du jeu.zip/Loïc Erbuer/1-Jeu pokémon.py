"""
_______________________________________________________________________________________________________________________________________________________________________
Bienvenue dans ce jeu qui reprend un projet python fait en terminale spécialité NSI.

Ce jeu consiste a un pokémon en tour par tour.

Il existe 50 pokémon différent.

Ce jeux a un système de login avec identifiant.

Il y a un système de classement par rapport au victoire et défaite.

Il existe différent états: Paralysie/Brulure/Poison/Dodo/Confus

Amusez-vous bien sur cette expérience.

Je suis encore au début de ce jeu alors désolé si il y a des erreurs et que cela est encore mal organisé uen fois dans le jeu.

Les améliorations seront apporté au fil et a mesure du temps car je n'est pas toujours l'inspiration pour créer.

Il y a un système d'objet.

Pour lancé le jeu juste a faire f5 ou écriver dans la console <fene()>.

Si vous voulez retrouver votre identifiant lancer le code quitter et faite <Utilisateur> et retrouver votre identifiant.




_______________________________________________________________________________________________________________________________________________________________________
"""
from tkinter import*
from pokemon import*
from combat import*
from Jeu import*
from projet import*
from random import*
from time import*
from PIL import *
from PIL import Image, ImageTk
A = Jeu()
ch,r,e,choix_attaque_utilisateur,rr,rrr,pa,pb,pc,w,gl,ge,Pec,Pm,Pe,Do,D,Vmax,my_entry,codea,utili,sac,f,difficulté=None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None,None
T=0
Pb=5
vic=0
defe=0
Utilisateur={}
Victoire = {}
Defaite = {}

def g():
    global Pm
    global Pe
    global Do
    global D
    global Pec
    global f
    global difficulté
    global ge
    global vic
    global defe
    ge=0
    D=2
g()

Pec=5
Pm=2
Pe=2
Do=2
D=2
"""
________________________________________________________________________________________________________________________________________________________
"""
def dico():
    with open("dico/Utilisateurs.txt", "r") as fichier:
        lignes = fichier.readlines()
    for ligne in lignes:
        Pseudo, Identifiant = ligne.strip().split(':')
        Utilisateur[Pseudo] = Identifiant
    with open("dico/Victoire.txt", "r") as fichier:
        lignes = fichier.readlines()
    for ligne in lignes:
        Pseudo, nbr = ligne.strip().split(':')
        Victoire[Pseudo] = int(nbr)
    with open("dico/Defaite.txt", "r") as fichier:
        lignes = fichier.readlines()
    for ligne in lignes:
        Pseudo, nbr = ligne.strip().split(':')
        Defaite[Pseudo] = int(nbr)
dico()
"""
________________________________________________________________________________________________________________________________________________________
"""
def Ns():
    global sac
    sac=[["Potion",10],["Super-Potion",5],["Hyper-Potion",2],["Reset-Etats",15],["Recharge-PP",5],["Recharge-All-PP",1]]
"""
________________________________________________________________________________________________________________________________________________________
"""
a=[5]
b=[5]
c=[5]
v=[5]
for i in range(len(A.Lp)):
    for e in range(len(A.Lp[i].lattaque)):
        if e==0:
            A.Lp[i].lattaque[0]+=a
        elif e==1:
            A.Lp[i].lattaque[1]+=b
        elif e==2:
            A.Lp[i].lattaque[2]+=c
        elif e==3:
            A.Lp[i].lattaque[3]+=v
        
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def afficher_image():
    chemin_image = "Autre/vic.jpg"  
    image = Image.open(chemin_image)
    photo = ImageTk.PhotoImage(image)

    label_image = Label(f, image=photo)
    label_image.image = photo
    label_image.pack()
"""
________________________________________________________________________________________________________________________________________________________
"""
def Passe():
    """
Permet de mettre 1 a la variable pour savoir si on passe les attaques ou pas
    """
    global ch
    ch=1
    diffi()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""    
def Bc():
    """
Permet de créer le Boutton pour un thème sombre
    """

    # Bouton pour changer de thème
    toggle_button = Button(f, text="Thème Sombre", command=switch_theme,font=("Helvetica", 25))
    toggle_button.pack(pady=10,side=LEFT)
"""
_______________________________________________________________________________________________________________________________________________________________________
"""    
def switch_theme():
    """
Le thème sombre défini
    """
    current_theme = f.option_get('theme', 'dark')
    new_theme = 'light' if current_theme == 'dark' else 'dark'
    f.tk_setPalette(background='#383838' if new_theme == 'dark' else 'white', foreground='white' if new_theme == 'dark' else 'black')
    f.option_add('*TButton*highlightBackground', 'black' if new_theme == 'dark' else 'white')
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def afficher():
    """
Permet de savoir la personne présente si il a un identifiant qui a été entré et recupérer c victoires/défaite ou sinon créer un identifiant
    """
    global codea
    global utili
    c=my_entry.get()
    utili=c
    if len(c)<=1:
        ac()
    else:
        Vide(f)
        if c in Utilisateur.values():
            for key, value in Utilisateur.items():
                if c == value:
                    J = Label(f, text="Bon retour parmi nous.", font=("Helvetica", 25))
                    J.pack()
                    Jo = Label(f, text=key, font=("Helvetica", 25))
                    Jo.pack()
            for key,value in Victoire.items():
                if c==key:
                    V=Label(f,text="Vous êtes resté à Victoire(s):",font=("Helvetica", 25))
                    Vi=Label(f,text=value,font=("Helvetica", 25))
                    V.pack()
                    Vi.pack()
            for key,value in Defaite.items():
                if c==key:
                    D=Label(f,text=" et vous êtes resté à Défaites(s):",font=("Helvetica", 25))
                    De=Label(f,text=value,font=("Helvetica", 25))
                    D.pack()
                    De.pack()
            Jw= Label(f, text="Si tu veux revoir les règles appuie sur <Règle> ou sinon appuie sur <Commencer>", font=("Helvetica", 25))
            Jw.pack()
            De = Button(f, text="Commencer", command=ChP, font=("Helvetica", 25))
            Dea = Button(f, text="Règle", command=départ, font=("Helvetica", 25))
            Dea.pack(pady=10)
            Dea.pack(side=LEFT)
            De.pack(pady=10)
            De.pack(side=RIGHT)
        else:
            er=randint(0,9)
            se=randint(0,9)
            tre=randint(0,9)
            er=str(er)
            se=str(se)
            tre=str(tre)
            code=[c[0],er,se,tre,c[-1]]
            codea="".join(code)
            print(code)
            J=Label(f,text="Votre code de personnage est:",font=("Helvetica", 25))
            Co=Label(f,text=code,font=("Helvetica", 25))
            J.pack()
            Utilisateur[c]=codea
            Co.pack()
            De = Button(f, text="Commencer", command=départ, font=("Helvetica", 25))
            De.pack(pady=10)
            De.pack(side=LEFT)
        
"""
_______________________________________________________________________________________________________________________________________________________________________
"""   
def destruction(w):
    """
Permet de détruire le widget associer
Param: la fenetre que l'on veut détruire
    """
    w.destroy()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def diffi():
    Vide(f)
    Jw= Label(f, text="Choisie ta difficulté", font=("Helvetica", 25))
    Jw.pack()
    d=Button(f, text="Easy", command=lambda diff="Easy": dif(diff), font=("Helvetica", 25))
    d.pack()
    d=Button(f, text="Normal", command=lambda diff="Normal" : dif(diff), font=("Helvetica", 25))
    d.pack()
    d=Button(f, text="Difficile", command=lambda diff="Difficile" : dif(diff) , font=("Helvetica", 25))
    d.pack()
    d=Button(f, text="Extrême", command=ext , font=("Helvetica", 25))
    d.pack()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def ext():
    Vide(f)
    chemin_image = "Autre/danger.png"  
    image = Image.open(chemin_image)
    resize_image = image.resize((250, 250))
    photo = ImageTk.PhotoImage(resize_image)
    label_image = Label(f, image=photo)
    label_image.image = photo
    label_image.pack(side=LEFT)
    J=Label(f,text="Êtes-vous bien sûr de ce choix??",font=("Helvetica", 50))
    J.pack(anchor=CENTER)
    frame = Frame(f)
    frame.pack()
    p=Button(frame,text="Oui",command=lambda diff="Extrême":dif(diff),font=("Helvetica", 25))
    d=Button(frame,text="Non",command=diffi,font=("Helvetica", 25))
    p.grid(row=1, column=0,pady=10,padx=10)
    d.grid(row=1, column=2,pady=10,padx=10)
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def dif(niv):
    global difficulté
    if niv=="Easy":
        difficulté=None
    if niv=="Normal":
        difficulté=1
    if niv=="Difficile":
        difficulté=2
    if niv=="Extrême":
        difficulté=3
    choix()
    
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def debut():
    """
lance le choix(), vide la page et créer le bouton pour quitter
    """
    Vide(f)
    choix()
    Bou()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def mettre_victoire(Pseudo, vic):

    with open("dico/Victoire.txt", "r") as fichier:
        lignes = fichier.readlines()
    vic2 = {}
    for ligne in lignes:
        nom, mot_de_passe = ligne.strip().split(':')
        vic2[nom] = mot_de_passe
    if Pseudo in vic2:
        for key, value in Victoire.items():
            if Pseudo == key:
                a=value 
                vic2[Pseudo] = vic+value
        with open("dico/Victoire.txt", "w") as fichier:
            for nom, mot_de_passe in vic2.items():
                fichier.write(f"{nom}:{mot_de_passe}\n")
"""
_______________________________________________________________________________________________________________________________________________________________________
"""                
def mettre_defaite(Pseudo, de):

    with open("dico/Defaite.txt", "r") as fichier:
        lignes = fichier.readlines()
    defa2 = {}
    for ligne in lignes:
        nom, mot_de_passe = ligne.strip().split(':')
        defa2[nom] = mot_de_passe
    if Pseudo in defa2:
        for key, value in Defaite.items():
            if Pseudo == key:
                a=value 
                defa2[Pseudo] = de+value
        with open("dico/Defaite.txt", "w") as fichier:
            for nom, mot_de_passe in defa2.items():
                fichier.write(f"{nom}:{mot_de_passe}\n")

"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def mett():
    if utili in Victoire:
        if difficulté==None:
            mettre_victoire(utili,A.getVictoire())
            mettre_defaite(utili,A.getDefaite())
        elif difficulté==1:
            mettre_victoire(utili,A.getVictoire()*2)
            mettre_defaite(utili,A.getDefaite()*2)
        elif difficulté==2:
            mettre_victoire(utili,A.getVictoire()*3)
            mettre_defaite(utili,A.getDefaite()*3)
        elif difficulté==3:
            mettre_victoire(utili,A.getVictoire()*3)
            mettre_defaite(utili,A.getDefaite()*3)
    else:
        if difficulté==None:
            fichier = open("dico/Utilisateurs.txt", "a")
            fichier.write(f"\n{utili}:{codea}")
            fichier.close()
            fichier = open("dico/Victoire.txt", "a")
            fichier.write(f"\n{codea}:{A.getVictoire()}")
            fichier.close()
            fichier = open("dico/Defaite.txt", "a")
            fichier.write(f"\n{codea}:{A.getDefaite()}")
            fichier.close()
        elif difficulté==1:
            fichier = open("dico/Utilisateurs.txt", "a")
            fichier.write(f"\n{utili}:{codea}")
            fichier.close()
            fichier = open("dico/Victoire.txt", "a")
            fichier.write(f"\n{codea}:{A.getVictoire()*2}")
            fichier.close()
            fichier = open("dico/Defaite.txt", "a")
            fichier.write(f"\n{codea}:{A.getDefaite()*2}")
            fichier.close()
        elif difficulté==2:
            fichier = open("dico/Utilisateurs.txt", "a")
            fichier.write(f"\n{utili}:{codea}")
            fichier.close()
            fichier = open("dico/Victoire.txt", "a")
            fichier.write(f"\n{codea}:{A.getVictoire()*3}")
            fichier.close()
            fichier = open("dico/Defaite.txt", "a")
            fichier.write(f"\n{codea}:{A.getDefaite()*3}")
            fichier.close()
        elif difficulté==3:
            fichier = open("dico/Utilisateurs.txt", "a")
            fichier.write(f"\n{utili}:{codea}")
            fichier.close()
            fichier = open("dico/Victoire.txt", "a")
            fichier.write(f"\n{codea}:{A.getVictoire()*5}")
            fichier.close()
            fichier = open("dico/Defaite.txt", "a")
            fichier.write(f"\n{codea}:{A.getDefaite()*5}")
            fichier.close()
    A.downDefaite()
    A.downVictoire()
    diffi()
"""
_______________________________________________________________________________________________________________________________________________________________________

"""
def quite():
    """
Permet de return les victoires/défaites sur la partie
    """
    global ge
    inter()
    mett()
    Vide(f)
    ge=1
    NbrV=Label(f,text="Vous avez gagné: ",font=("Helvetica", 25))
    NbrVi=Label(f,text=vic,font=("Helvetica", 25))
    NbrD=Label(f,text="Vous avez perdu:",font=("Helvetica", 25))
    Nbrde=Label(f,text=defe,font=("Helvetica", 25))
    NbrV.pack()
    NbrVi.pack()
    NbrD.pack()
    Nbrde.pack()
    C=Button(f, text="Acceuil", command=ac, font=("Helvetica", 25))
    C.pack(side=LEFT)
    Bou()
    
"""
_______________________________________________________________________________________________________________________________________________________________________
"""    
def Bou():
    """
Permet de créer le boutton pour quitter
    """
    B = Button(f, text="Quitter", command=close, font=("Helvetica", 25))
    B.pack(pady=10)
    B.pack(side=RIGHT)
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def close():
    """
Détruit le fenêtre
    """
    f.destroy()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def maximizer(window):
    """
Permet d'obtenir la largeur de la fenêtre et la longueur
    """
    # Obtient la largeur et la hauteur maximale de l'écran
    screen_width = window.winfo_screenwidth()
    screen_height = window.winfo_screenheight()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def Vide(parent):
    """
Permet de vider la fenêtre entière
    """
    for widget in parent.winfo_children():
        widget.destroy()

"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def assign_pokemon(pokemon):
    """
Permet de choisir le pokémon pour le combat
    """
    global e
    global Vmax
    global T
    global w
    T=0
    Vide(f)
    if pokemon ==pa:
        w=int(r)
    elif pokemon ==pb:
        w=int(rr)
    elif pokemon ==pc:
        w=int(rrr)
    Bou()
    L = Label(f, text="Vous avez choisi:", font=("Helvetica", 20))
    La = Label(f, text=A.Lp[w].getNom(), font=("Helvetica", 20))
    Vmax=A.Lp[w].getVie()
    L.pack(side=TOP, anchor=CENTER)
    La.pack(side=TOP, anchor=CENTER)
    ImPo(w)
    En=Label(f,text="Le pokémon adverse est :",font=("Helvetica",20))
    E=Label(f,text=A.Lp[e].getNom(),font=("Helvetica",20))
    En.pack(side=TOP, anchor=CENTER)
    E.pack(side=TOP, anchor=CENTER)
    ImPo(e)
    Bt=Button(f,text="Prêt ?",font=("Helvetica",20),command=att)
    Bt.pack(side=TOP, anchor=CENTER)
"""
_______________________________________________________________________________________________________________________________________________________________________
"""    
def att():
    """
Lance le jeu
    """
    Vide(f)
    Bou()
    attaque()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def UpT():
    """
Permet de faire monter le nbr de tours pour savoir quelle tour sommes nous
    """
    global T
    T+=1
    To=Label(f,text=T,font=("Helvetica", 20))
    To.pack()
    
"""
_______________________________________________________________________________________________________________________________________________________________________
"""    
def Upto():
    """
Idem que UpT
    """
    global T
    T+=1
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def ImPo(z):
    if A.Lp[z].getNom()=="Pikachu":
        chemin_image = "im P/pikaa.png"  
    elif A.Lp[z].getNom()=="Raichu":
        chemin_image = "im P/Rai.png"  
    elif A.Lp[z].getNom()=="Demoloss":
        chemin_image = "im P/Dem.png"  
    elif A.Lp[z].getNom()=="Mewtwo":
        chemin_image = "im P/mewtwo.png"  
    elif A.Lp[z].getNom()=="Dracaufeu":
        chemin_image = "im P/drac.png"  
    elif A.Lp[z].getNom()=="Arcanin":
        chemin_image = "im P/arca.png"  
    elif A.Lp[z].getNom()=="Mew":
        chemin_image = "im P/mew.png"  
    elif A.Lp[z].getNom()=="Ectoplasma":
        chemin_image = "im P/ecto.png"  
    elif A.Lp[z].getNom()=="Bullbizare":
        chemin_image = "im P/bulbi.png"  
    elif A.Lp[z].getNom()=="Leviator":
        chemin_image = "im P/levia.png"  
    elif A.Lp[z].getNom()=="Dodrio":
        chemin_image = "im P/dodri.png"  
    elif A.Lp[z].getNom()=="Excelangue":
        chemin_image = "im P/exce.png"  
    elif A.Lp[z].getNom()=="Feuillajou":
        chemin_image = "im P/feuil.png"  
    elif A.Lp[z].getNom()=="Fluvetin":
        chemin_image = "im P/fluve.png"  
    elif A.Lp[z].getNom()=="Tortank":
        chemin_image = "im P/tort.png"  
    elif A.Lp[z].getNom()=="Florizarre":
        chemin_image = "im P/floriz.png"  
    elif A.Lp[z].getNom()=="Empiflor":
        chemin_image = "im P/empif.png"  
    elif A.Lp[z].getNom()=="Alakazam":
        chemin_image = "im P/alaka.png"  
    elif A.Lp[z].getNom()=="Dodrio":
        chemin_image = "im P/dodri.png"  
    elif A.Lp[z].getNom()=="Ronflex":
        chemin_image = "im P/ronfl.png"  
    elif A.Lp[z].getNom()=="Leveinard":
        chemin_image = "im P/leve.png"  
    elif A.Lp[z].getNom()=="Flagadoss":
        chemin_image = "im P/flagado.png"  
    elif A.Lp[z].getNom()=="Aeromite":
        chemin_image = "im P/aero.png"  
    elif A.Lp[z].getNom()=="Magicarp":
        chemin_image = "im P/magica.png"  
    elif A.Lp[z].getNom()=="Noadkoko":
        chemin_image = "im P/Noadkoko.png"  
    elif A.Lp[z].getNom()=="Cloyster":
        chemin_image = "im P/cloy.png"  
    elif A.Lp[z].getNom()=="Exagide":
        chemin_image = "im P/exag.png"  
    elif A.Lp[z].getNom()=="Nymphali":
        chemin_image = "im P/nymp.jpg"  
    elif A.Lp[z].getNom()=="Amphinobi":
        chemin_image = "im P/amphi.jpg"  
    elif A.Lp[z].getNom()=="Ptyranidur":
        chemin_image = "im P/ptira.jpg"  
    elif A.Lp[z].getNom()=="Triopikeur":
        chemin_image = "im P/trio.jpg"  
    elif A.Lp[z].getNom()=="Papilusion":
        chemin_image = "im P/papi.jpg"  
    elif A.Lp[z].getNom()=="Drattak":
        chemin_image = "im P/dra.jpg"  
    elif A.Lp[z].getNom()=="Gardevoir":
        chemin_image = "im P/gard.jpg"  
    elif A.Lp[z].getNom()=="Steelix":
        chemin_image = "im P/stee.jpg"  
    elif A.Lp[z].getNom()=="Jirachi":
        chemin_image = "im P/jira.jpg"  
    elif A.Lp[z].getNom()=="Absol":
        chemin_image = "im P/abs.jpg"  
    elif A.Lp[z].getNom()=="Gallame":
        chemin_image = "im P/gala.jpg"  
    elif A.Lp[z].getNom()=="Pingoléon":
        chemin_image = "im P/pin.jpg"  
    elif A.Lp[z].getNom()=="Mammochon":
        chemin_image = "im P/mam.jpg"  
    elif A.Lp[z].getNom()=="Carchacrok":
        chemin_image = "im P/carcha.jpg"  
    elif A.Lp[z].getNom()=="Démétéros":
        chemin_image = "im P/deme.jpg"  
    elif A.Lp[z].getNom()=="Boréas":
        chemin_image = "im P/bor.jpg"  
    elif A.Lp[z].getNom()=="Noctali":
        chemin_image = "im P/noct.jpg"  
    elif A.Lp[z].getNom()=="Goinfrex":
        chemin_image = "im P/goin.jpg"  
    elif A.Lp[z].getNom()=="Psykokwak":
        chemin_image = "im P/psy.jpg"  
    elif A.Lp[z].getNom()=="Lougaroc":
        chemin_image = "im P/louga.png"  
    elif A.Lp[z].getNom()=="Topikeur":
        chemin_image = "im P/topi.jpg"  
    elif A.Lp[z].getNom()=="Métamorph":
        chemin_image = "im P/meta.jpg"  
    elif A.Lp[z].getNom()=="Meloetta":
        chemin_image = "im P/melo.jpg"  
    elif A.Lp[z].getNom()=="Rattatac":
        chemin_image = "im P/rat.jpg"  
    image = Image.open(chemin_image)
    resize_image = image.resize((250, 250))
    photo = ImageTk.PhotoImage(resize_image)
    label_image = Label(f, image=photo)
    label_image.image = photo
    label_image.pack()
    
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def inti():
    Vide(f)
    inter()
    P=Label(f,text="Veux-tu rejouer au même niveau?", font=("Helvetica", 40))
    P.pack()
    frame = Frame(f)
    frame.pack()
    p=Button(frame,text="Oui",command=choix,font=("Helvetica", 25))
    d=Button(frame,text="Non",command=mett,font=("Helvetica", 25))
    p.grid(row=1, column=0,pady=10,padx=10)
    d.grid(row=1, column=2,pady=10,padx=10)

"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def inter():
    global vic
    global defe
    vic+=A.getVictoire()
    defe+=A.getDefaite()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def attaque():
    """
Lance l'attaque du joueur en faisant un choix est regarde si il les conditions de victoire/défaites sont remplis
    """
    global Pm
    global Pb
    pol=1
    if A.Lp[e].hp<=0:
        Vide(f)
        global gl
        A.setVictoire()
        P=Label(f,text="Vous avez gagné", font=("Helvetica", 40))
        P.pack()
        if w<e:
            del A.Lp[e]
            del A.Lp[w]
        else:    
            del A.Lp[w]
            del A.Lp[e]
        De = Button(f, text="Continuer", command=inti, font=("Helvetica", 25))
        De.pack(pady=10)
        De.pack(side=LEFT)
        B = Button(f, text="Quitter", command=quite, font=("Helvetica", 25))
        B.pack(pady=10)
        B.pack(side=RIGHT)
        chemin_image = "Autre/vic.png"  
        image = Image.open(chemin_image)
        photo = ImageTk.PhotoImage(image)

        label_image = Label(f, image=photo)
        label_image.image = photo
        label_image.pack()
        
        return "gg"
    elif A.Lp[w].hp<=0:
        Vide(f)
        A.setDefaite()
        P=Label(f,text="Vous avez perdu", font=("Helvetica", 40))
        P.pack()
        if w<e:
            del A.Lp[e]
            del A.Lp[w]
        else:    
            del A.Lp[w]
            del A.Lp[e]
        De = Button(f, text="Continuer", command=inti, font=("Helvetica", 25))
        De.pack(pady=10)
        De.pack(side=LEFT)
        B = Button(f, text="Quitter", command=quite, font=("Helvetica", 25))
        B.pack(pady=10)
        B.pack(side=RIGHT)
        chemin_image = "Autre/per.png"  
        image = Image.open(chemin_image)
        photo = ImageTk.PhotoImage(image)
        resize_image = image.resize((900, 750))
        photo = ImageTk.PhotoImage(resize_image)
        label_image = Label(f, image=photo)
        label_image.image = photo
        label_image.pack()
        return "gg"
    else:
        Vide(f)
        Bou()
        T=Label(f,text="Tour :",font=("Helvetica", 20))
        T.pack()
        UpT()
        if A.Lp[w].getEtat()=="Brulure" or A.Lp[w].getEtat()=="Normal" or A.Lp[w].getEtat()=="Confus" or A.Lp[w].getEtat()=="Poison" or A.Lp[w].getEtat()=="Dodo" or A.Lp[w].getEtat()=="Paralysie"  :
            if A.Lp[w].getEtat()=="Brulure":
                A.Lp[w].hp-=5
                B=Label(f, text="  Tu es Bruler donc tu perdra de la vie.", font=("Helvetica", 20))
                Pb=Pb-1
                if Pb==0:
                    A.Lp[w].setEtat("Normal")
                    Pb=5
                B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
                B.pack(pady=8)
            if A.Lp[w].getEtat()=="Poison":
                A.Lp[w].hp-=5
                B=Label(f, text="  Tu es empoisoné donc tu perdra de la vie.", font=("Helvetica", 20))
                B.pack()
                Pb=Pb-1
                if Pb==0:
                    A.Lp[w].setEtat("Normal")
                    Pb=5
            if A.Lp[w].getEtat()=="Confus":
                z=randint(1,2)
                if z==2:
                    pol=2
                    A.Lp[w].hp-=10
                    B=Label(f, text="  Tu es Confus, et tu t'es attaquer tous seul.", font=("Helvetica", 20))
                    B.pack()
                    A.Lp[w].setEtat("Normal")
                    B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
                    B.pack(pady=8)
                    Sacaa=Button(f,text="Sac", font=("Helvetica", 30), command=sace)
                    Sacaa.pack()
            if A.Lp[w].getEtat()=="Paralysie":
                pol=2
                Pm=Pm-1
                P=Label(f, text="  Tu es paralysée donc tu peux pas attaquer", font=("Helvetica", 20))
                P.pack()
                if Pm==0:
                    A.Lp[w].setEtat("Normal")
                    Pm=2
                B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
                B.pack(pady=8)
                Sacaa=Button(f,text="Sac", font=("Helvetica", 30), command=sace)
                Sacaa.pack()
            if A.Lp[w].getEtat()=="Dodo":
                global Do
                pol=2
                Do=Do-1
                P=Label(f, text="  Tu es endormi donc tu peux pas attaquer", font=("Helvetica", 20))
                P.pack()
                B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
                B.pack(pady=8)
                if Do==0:
                    A.Lp[w].setEtat("Normal")
                    Do=2
                Sacaa=Button(f,text="Sac", font=("Helvetica", 30), command=sace)
                Sacaa.pack()
                
            if pol==1:
                Vie = Label(f, text="Votre vie est de:", font=("Helvetica", 20))
                V = Label(f, text=A.Lp[w].getVie(), font=("Helvetica", 20))
                P = Label(f, text="Choisissez votre attaque:",font=("Helvetica", 20))
                Vie.pack()
                V.pack()
                P.pack()
                frame = Frame(f)
                frame.pack()
                pm=Label(frame,text="Dégats/Etat:",font=("Helvetica", 20))
                pc=Label(frame,text="Dégats:",font=("Helvetica", 20))
                pb=Label(frame,text="PP:",font=("Helvetica", 20))
                pd=Label(frame,text="PP:",font=("Helvetica", 20))
                pm.grid(row=1, column=0,pady=10,padx=10)
                pc.grid(row=4, column=0,pady=10,padx=10)
                pb.grid(row=2, column=0,pady=10,padx=10)
                pd.grid(row=5, column=0,pady=10,padx=10)
                for i in range(len(A.Lp[w].lattaque)):
                    attaque_name = A.Lp[w].lattaque[i]
                    Pa = Button(frame, text=attaque_name[0], command=lambda attaque=attaque_name: choix_attaque(attaque), font=("Helvetica", 20))
                    t=Label(frame,text=A.Lp[w].lattaque[i][1],font=("Helvetica", 20))
                    c=Label(frame,text=A.Lp[w].lattaque[i][2],font=("Helvetica", 20))
                    if i==0 or i==2:
                        Pa.grid(row=0, column=i+1,pady=10,padx=10)
                        t.grid(row=1, column=i+1,pady=10,padx=10)
                        c.grid(row=2, column=i+1,pady=10,padx=10)
                    else:
                        i -=1
                        Pa.grid(row=3, column=i+1,pady=10,padx=10)
                        t.grid(row=4, column=i+1,pady=10,padx=10)
                        c.grid(row=5, column=i+1,pady=10,padx=10)
                ViE=Label(f,text="La vie de votre adversaire est de :", font=("Helvetica", 20))
                Va=Label(f,text=A.Lp[e].getVie(),font=("Helvetica", 20))
                Etat=Label(f,text=A.Lp[e].getEtat(),font=("Helvetica", 20))
                ViE.pack()
                Va.pack()
                Etat.pack()
                Sacaa=Button(f,text="Sac", font=("Helvetica", 30), command=sace)
                Sacaa.pack()
            
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def choix_attaque(attaque_name):
    """
Nous montre l'attaque choisie
    """
    Vide(f)
    global choix_attaque_utilisateur
    choix_attaque_utilisateur = attaque_name
    degats=attaque_name[1]
    Bou()
    if ch==None:
        Z=Label(f,text="Vous avez choisie:",font=("Helvetica", 30))
        P=Label(f,text=attaque_name[0],font=("Helvetica", 30))
        Z.pack()
        P.pack()
    if type(degats)==int:
        if attaque_name==A.Lp[w].lattaque[0]:
            if attaque_name[2]!=0:
                A.Lp[e].hp-=attaque_name[1]-(A.Lp[e].defe/2)
                A.Lp[w].lattaque[0][2]-=1
            else:
                Z=Label(f,text="L'attaque n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                Z.pack()
        if attaque_name==A.Lp[w].lattaque[1]:
            if attaque_name[2]!=0:
                A.Lp[e].hp-=attaque_name[1]-(A.Lp[e].defe/2)
                A.Lp[w].lattaque[1][2]-=1
            else:
                Z=Label(f,text="L'attaque n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                Z.pack()
        if attaque_name==A.Lp[w].lattaque[3]:
            if attaque_name[2]!=0:
                A.Lp[e].hp-=attaque_name[1]-(A.Lp[e].defe/2)
                A.Lp[w].lattaque[3][2]-=1
            else:
                Z=Label(f,text="L'attaque n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                Z.pack()  
    else:
        if attaque_name[2]!=0:
            A.Lp[e].setEtat(attaque_name[1])
            A.Lp[w].lattaque[2][2]-=1
        else:
            Z=Label(f,text="L'attaque n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
            Z.pack()
    if ch==None:
        B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
        B.pack(pady=8)
    if ch==1:
        attaqueE()
    
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def sace():
    Vide(f)
    frame = Frame(f)
    frame.pack()
    pm=Label(frame,text="Objets:",font=("Helvetica", 20))
    pc=Label(frame,text="Objet:",font=("Helvetica", 20))
    pe=Label(frame,text="Objet:",font=("Helvetica", 20))
    pb=Label(frame,text="PP:",font=("Helvetica", 20))
    pd=Label(frame,text="PP:",font=("Helvetica", 20))
    pvd=Label(frame,text="PP:",font=("Helvetica", 20))
    pm.grid(row=1, column=0,pady=10,padx=10)
    pc.grid(row=4, column=0,pady=10,padx=10)
    pb.grid(row=2, column=0,pady=10,padx=10)
    pd.grid(row=5, column=0,pady=10,padx=10)
    pe.grid(row=7, column=0,pady=10,padx=10)
    pvd.grid(row=8, column=0,pady=10,padx=10)
    for i in range(len(sac)):
        objet=sac[i]
        Pa = Button(frame, text=objet[0], command=lambda objet_U=objet: objU(objet_U), font=("Helvetica", 20))
        t=Label(frame,text=sac[i][0],font=("Helvetica", 20))
        c=Label(frame,text=sac[i][1],font=("Helvetica", 20))
        if i==0 or i==3:
            if i==3:
                i-=2
            Pa.grid(row=0, column=i+1,pady=10,padx=10)
            t.grid(row=1, column=i+1,pady=10,padx=10)
            c.grid(row=2, column=i+1,pady=10,padx=10)
        elif i==1 or i==4:
            if i==1:
                i -=1
            if i==4:
                i-=3
            Pa.grid(row=3, column=i+1,pady=10,padx=10)
            t.grid(row=4, column=i+1,pady=10,padx=10)
            c.grid(row=5, column=i+1,pady=10,padx=10)
        elif i==2 or i==5:
            if i==2:
                i-=2
            if i==5:
                i-=4
            Pa.grid(row=6, column=i+1,pady=10,padx=10)
            t.grid(row=7, column=i+1,pady=10,padx=10)
            c.grid(row=8, column=i+1,pady=10,padx=10)
    B = Button(f, text="Retour", font=("Helvetica", 30), command=attaque)
    B.pack(pady=8)
"""
________________________________________________________________________________________________________________________________________________________
"""
def objU(Obj):
    Vide(f)
    Z=Label(f,text="Vous avez utiliser:",font=("Helvetica", 30))
    P=Label(f,text=Obj[0],font=("Helvetica", 30))
    Z.pack()
    P.pack()
    if Obj[0]=="Potion":
        if Obj[1]!=0:
            if A.Lp[w].getVie()<=Vmax:
                A.Lp[w].upVie(15)
                Obj[1]-=1
                if A.Lp[w].getVie()>Vmax:
                    v=A.Lp[w].getVie()-Vmax
                    A.Lp[w].hp-=v
            else:
                a=Label(f,text="Vous avez utiliser une potion pour rien",font=("Helvetica", 20))
                a.pack()
                Obj[1]-=1
        else:
            sace()
        B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
        B.pack(pady=8)
    elif Obj[0]=="Super-Potion":
        if Obj[1]!=0:
            if A.Lp[w].getVie()<=Vmax:
                A.Lp[w].upVie(35)
                Obj[1]-=1
                if A.Lp[w].getVie()>Vmax:
                    v=A.Lp[w].getVie()-Vmax
                    A.Lp[w].hp-=v
            else:
                a=Label(f,text="Vous avez utiliser une potion pour rien",font=("Helvetica", 20))
                a.pack()
                Obj[1]-=1
        else:
            sace()
        B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
        B.pack(pady=8)
    elif Obj[0]=="Hyper-Potion":
        if Obj[1]!=0:
            if A.Lp[w].getVie()<=Vmax:
                A.Lp[w].upVie(50)
                Obj[1]-=1
                if A.Lp[w].getVie()>Vmax:
                    v=A.Lp[w].getVie()-Vmax
                    A.Lp[w].hp-=v
            else:
                a=Label(f,text="Vous avez utiliser une potion pour rien",font=("Helvetica", 20))
                a.pack()
                Obj[1]-=1
        else:
            sace()
        B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
        B.pack(pady=8)
    elif Obj[0]=="Reset-Etat":
        if Obj[1]!=0:
            A.Lp[w].setEtat("Normal")
            Obj[1]-=1
        else:
            sace()
        B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
        B.pack(pady=8)
    elif Obj[0]=="Recharge-PP":
        a=Label(f,text="Choississez l'attaque que vous voulez recharger",font=("Helvetica", 20))
        a.pack()
        frame = Frame(f)
        frame.pack()
        for i in range(len(A.Lp[w].lattaque)):
            attaque_name = A.Lp[w].lattaque[i]
            Pa = Button(frame, text=attaque_name[0], command=lambda attaque=attaque_name: recharge(attaque), font=("Helvetica", 20))
            t=Label(frame,text=A.Lp[w].lattaque[i][1],font=("Helvetica", 20))
            c=Label(frame,text=A.Lp[w].lattaque[i][2],font=("Helvetica", 20))
            if i==0 or i==2:
                Pa.grid(row=0, column=i+1,pady=10,padx=10)
                t.grid(row=1, column=i+1,pady=10,padx=10)
                c.grid(row=2, column=i+1,pady=10,padx=10)
            else:
                i -=1
                Pa.grid(row=3, column=i+1,pady=10,padx=10)
                t.grid(row=4, column=i+1,pady=10,padx=10)
                c.grid(row=5, column=i+1,pady=10,padx=10)
    else:
        r=8-A.Lp[w].lattaque[0][2]
        A.Lp[w].lattaque[0][2]+=r
        r=5-A.Lp[w].lattaque[1][2]
        A.Lp[w].lattaque[1][2]+=r
        r=5-A.Lp[w].lattaque[2][2]
        A.Lp[w].lattaque[2][2]+=r
        r=8-A.Lp[w].lattaque[3][2]
        A.Lp[w].lattaque[3][2]+=r
        B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
        B.pack(pady=8)
            
        
        
    
"""
__________________________________________________________________________________________________________________________________________________________
"""
def recharge(atta):
    Vide(f)
    a=Label(f,text="L'attaque recharger est un succés",font=("Helvetica", 20))
    a.pack()
    if atta==A.Lp[w].lattaque[0]:
        r=8-A.Lp[w].lattaque[0][2]
        A.Lp[w].lattaque[0][2]+=r
    if atta==A.Lp[w].lattaque[1]:
        r=5-A.Lp[w].lattaque[1][2]
        A.Lp[w].lattaque[1][2]+=r
    if atta==A.Lp[w].lattaque[2]:
        r=5-A.Lp[w].lattaque[2][2]
        A.Lp[w].lattaque[2][2]+=r
    if atta==A.Lp[w].lattaque[3]:
        r=8-A.Lp[w].lattaque[3][2]
        A.Lp[w].lattaque[3][2]+=r
    B = Button(f, text="Continuer", font=("Helvetica", 30), command=attaqueE)
    B.pack(pady=8)
        
"""
__________________________________________________________________________________________________________________________________________________________
"""
def attaqueE():
    """
L'attaque choisie pour l'enemi en fait aléatoire
    """
    global Pe
    global Pec
    ae=randint(1,4)
    z=randint(1,2)
    poi=1
    if A.Lp[e].hp<=0:
        attaque()
    else:
        Upto()
        Vide(f)
        if A.Lp[e].getEtat()=="Paralysie":
            Pe=Pe-1
            if ch!=0:
                P=Label(f,text="Le pokémon adverse est paralysé donc n'attaque pas",font=("Helvetica", 30))
                P.pack()
            B = Button(f, text="Continuer",command=attaque, font=("Helvetica", 30))
            B.pack()
            
        if A.Lp[e].getEtat()=="Dodo":
            global D
            bb=D-1
            D=bb
            P=Label(f, text="  Le Pokémon ennemi est endormi donc tu peux pas attaquer", font=("Helvetica", 20))
            P.pack()
            B = Button(f, text="Continuer",command=attaque, font=("Helvetica", 30))
            B.pack()
            if D==0:
                A.Lp[e].setEtat("Normal")
                D=2
        else:
            if A.Lp[e].getEtat()=="Brulure":
                A.Lp[e].hp-=5
                Pec=Pec-1
                if Pec==0:
                    A.Lp[w].setEtat("Normal")
                    Pec=5
                if ch!=1:
                    P=Label(f,text="Le pokémon adverse est Bruler donc perdra de la vie en plus",font=("Helvetica", 30))
                    P.pack()
            if A.Lp[e].getEtat()=="Poison":
                A.Lp[e].hp-=5
                Pec=Pec-1
                if ch!=1:
                    P=Label(f,text="Le pokémon adverse est empoisoné donc perdra de la vie en plus",font=("Helvetica", 30))
                    P.pack()
                    B = Button(f, text="Continuer",command=attaque, font=("Helvetica", 30))
                    B.pack()
            if A.Lp[e].getEtat()=="Confus":
                poi=1
                if z==2:
                    poi=2
                    A.Lp[e].hp-=10
                    B=Label(f, text="  Le pokémon ennemi est Confus, et il s'est attaquer tous seul.", font=("Helvetica", 20))
                    B.pack()
                    A.Lp[e].setEtat("Normal")
                    B = Button(f, text="Continuer",command=attaque, font=("Helvetica", 30))
                    B.pack()
            if A.Lp[e].getEtat()=="Confus" or A.Lp[e].getEtat()=="Normal" or A.Lp[e].getEtat()=="Brulure" or A.Lp[e].getEtat()=="Poison":
                if poi==1:
                    if ch!=1:
                        Bou()
                        if ae==1 or ae==2 or ae==4 or ae==3:
                            if ae==3:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    A.Lp[w].setEtat(A.Lp[e].lattaque[ae-1][1])
                                    A.Lp[e].lattaque[2][2]-=1
                                    P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                    Pa=Label(f,text=A.Lp[e].lattaque[2][0],font=("Helvetica", 30))
                                    P.pack()
                                    Pa.pack()               
                                else:
                                    Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                    Z.pack()
                            if difficulté==None:
                                if ae==1:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[0][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]-(A.Lp[w].defe/2)
                                        A.Lp[e].lattaque[0][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                                if ae==2:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]-(A.Lp[w].defe/2)
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[1][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        
                                        A.Lp[e].lattaque[1][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                                if ae==4:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]-(A.Lp[w].defe/2)
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[3][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        
                                        A.Lp[e].lattaque[3][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                            elif difficulté==1:
                                if ae==1:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[0][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]
                                        A.Lp[e].lattaque[0][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                                if ae==2:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[1][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        
                                        A.Lp[e].lattaque[1][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                                if ae==4:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[3][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        
                                        A.Lp[e].lattaque[3][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                            elif difficulté==2:
                                if ae==1:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[0][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]*2/2
                                        A.Lp[e].lattaque[0][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                                if ae==2:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]*2/2
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[1][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        
                                        A.Lp[e].lattaque[1][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                                if ae==4:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]*2/2
                                        P=Label(f,text="Le pokémon adverse a lancé",font=("Helvetica", 30))
                                        Pa=Label(f,text=A.Lp[e].lattaque[3][0],font=("Helvetica", 30))
                                        P.pack()
                                        Pa.pack()
                                        
                                        A.Lp[e].lattaque[3][2]-=1
                                    else:
                                        Z=Label(f,text="L'attaque ennemi n'as plus de PP dommage vous perdez un tour.",font=("Helvetica", 30))
                                        Z.pack()
                            B = Button(f, text="Continuer",command=attaque, font=("Helvetica", 30))
                            B.pack()
                    if ch==1:
                        if ae==3:
                            if A.Lp[e].lattaque[ae-1][2]!=0:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    A.Lp[w].setEtat(A.Lp[e].lattaque[ae-1][1])
                                    A.Lp[e].lattaque[2][2]-=1
                        if difficulté==None:
                            if ae==1:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]-(A.Lp[w].defe/2)
                                        A.Lp[e].lattaque[0][2]-=1       
                                if ae==2:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        if A.Lp[e].lattaque[ae-1][2]!=0:
                                            A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]-(A.Lp[w].defe/2)
                                            A.Lp[e].lattaque[1][2]-=1
                                if ae==4:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        if A.Lp[e].lattaque[ae-1][2]!=0:
                                            A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]-(A.Lp[w].defe/2)
                                            A.Lp[e].lattaque[3][2]-=1
                        elif difficulté==1:
                            if ae==1:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]
                                        A.Lp[e].lattaque[0][2]-=1                              
                                if ae==2:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        if A.Lp[e].lattaque[ae-1][2]!=0:
                                            A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]                                                                        
                                            A.Lp[e].lattaque[1][2]-=1                                
                                if ae==4:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        if A.Lp[e].lattaque[ae-1][2]!=0:
                                            A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]                                                                        
                                            A.Lp[e].lattaque[3][2]-=1
                        elif difficulté==2:
                            if ae==1:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=round(A.Lp[e].lattaque[ae-1][1]*2/1,5)
                                        A.Lp[e].lattaque[0][2]-=1
                            if ae==2:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=round(A.Lp[e].lattaque[ae-1][1]*2 /1,5 )                              
                                        A.Lp[e].lattaque[1][2]-=1
                            if ae==4:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=round(A.Lp[e].lattaque[ae-1][1]*2/1,5)
                                        A.Lp[e].lattaque[3][2]-=1
                        elif difficulté==3:
                            if ae==1:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]*2
                                        A.Lp[e].lattaque[0][2]-=1       
                            if ae==2:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]*2
                                        A.Lp[e].lattaque[1][2]-=1
                            if ae==4:
                                if A.Lp[e].lattaque[ae-1][2]!=0:
                                    if A.Lp[e].lattaque[ae-1][2]!=0:
                                        A.Lp[w].hp-=A.Lp[e].lattaque[ae-1][1]*2
                                        A.Lp[e].lattaque[3][2]-=1
        if Pe==0:
            A.Lp[e].setEtat("Normal")
            Pe=2
        if Pec==0:
            A.Lp[w].setEtat("Normal")
            Pec=5
            attaque()
        if ch==1:
            attaque()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def choix():
    """
Force la fin si la liste des pokémon est vide ou lance les choix possible de pokémon
    """
    Ns()
    global r
    global e
    global rr
    global rrr
    global pa
    global pb
    global pc
    Vide(f)
    if len(A.Lp)<3:
        F = Label(f, text="Plus de choix possible", font=("Helvetica", 35))
        F.pack()
        B = Button(f, text="Fin", command=quite, font=("Helvetica", 25))
        B.pack(pady=10)
        
    else:   
        r=0
        rr=randint(0,len(A.Lp)-1)
        rrr=randint(0,len(A.Lp)-1)
        e=randint(0,len(A.Lp)-1)
        if e!=r and e!=rr and e!=rrr and r!=rr and r!=rrr and rr!=rrr:
            pokemona=A.Lp[r]
            pokemonb=A.Lp[rr]
            pokemonc=A.Lp[rrr]
            pa=pokemona
            pb=pokemonb
            pc=pokemonc
            F = Label(f, text="Vous avez le choix entre ces 3 pokémon:", font=("Helvetica",45))
            F.pack()
            frame = Frame(f)
            frame.pack()
            text=Label(frame, text="", font=("Helvetica",45))
            text.grid(row=1, column=1,pady=10,padx=10)
            text=Label(frame, text="", font=("Helvetica",45))
            text.grid(row=2, column=3,pady=10,padx=10)
            text=Label(frame, text="", font=("Helvetica",45))
            text.grid(row=3, column=5,pady=10,padx=10)
            B = Button(frame, text=A.Lp[r].getNom(), font=("Helvetica", 45), command=lambda pa=pokemona: assign_pokemon(pa))
            B.grid(row=4, column=0,pady=10,padx=10)
            Ba = Button(frame, text=A.Lp[rr].getNom(), font=("Helvetica", 45), command=lambda pb=pokemonb: assign_pokemon(pb))
            Ba.grid(row=4, column=2,pady=10,padx=10)
            Bz = Button(frame, text=A.Lp[rrr].getNom(), font=("Helvetica", 45), command=lambda pc=pokemonc: assign_pokemon(pc))
            Bz.grid(row=4, column=4,pady=10,padx=10)
        else:
            choix()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
# global f
# f = Tk()
# f.attributes('-fullscreen', True)
# maximizer(f)
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def ChP():
    """
Demande si il veulent passé les attaques ou pas
    """
    Vide(f)
    Z=Label(f,text="Veux-tu passer les choix d'attaque?\n Oui=On ne voit pas les attaques lancées par l'adversaire\n Non= On voit les attaques lancées par l'adversaire",font=("Helvetica", 45))
    A=Button(f,text="Oui",command=Passe,font=("Helvetica", 50))
    B=Button(f,text="Non",command=diffi,font=("Helvetica", 50))
    Z.pack()
    text=Label(f, text="", font=("Helvetica",35))
    text.pack()
    A.pack()
    text=Label(f, text="", font=("Helvetica",35))
    text.pack()
    B.pack()
    
"""
_______________________________________________________________________________________________________________________________________________________________________
"""    
def départ():
    """
Nous montre le règlement du jeu
    """
    Vide(f)
    a = Label(f, text="Bienvenue dans ce jeu Pokémon.\n Je me présente Loïc le créateur de ce jeu en Thonny.\n Le but de se jeu est de faire de multiples combats.\n Lors de la prochaine page après avoir cliqué sur commencer, vous choisirez votre pokémon.\n Ensuite vous allez vous combattre contre un bot.\n Amusez-vous bien!!! \n Pour information les chiffres/états écrits en dessous des bouttons lors du choix d'attaque,\n cela représente si il fait des dégats ou un effet d'état.\nEt l'autre chiffres est le nombre de PP ", font=("Helvetica", 25))
    a.pack(pady=10)
    a.pack(side=TOP, anchor=CENTER, expand=YES)
    De = Button(f, text="Commencer", command=ChP, font=("Helvetica", 25))
    De.pack(pady=10)
    De.pack(side=LEFT)
"""
_______________________________________________________________________________________________________________________________________________________________________
"""    
def classement():
     """
Créer le classement de tous ceux qui sont enregistrer
     """
     from tkinter import ttk
     global ge
     dico()
     ge=1
     Vide(f)
     tree = ttk.Treeview(f, columns=("Nombre de combats", "Nombres de Victoires", "Nombre de défaite"),height=20)
     tree.heading("#0", text="Nom du Joueur")
     tree.heading("Nombre de combats", text="Nombre de combats")
     tree.heading("Nombres de Victoires", text="Nombres de Victoires")
     tree.heading("Nombre de défaite", text="Nombre de défaite")
     tree.column("#0", width=250)
     tree.column("Nombre de combats", width=200)
     tree.column("Nombres de Victoires", width=200)
     tree.column("Nombre de défaite", width=200)
     custom_font = ("Helvetica", 15)
     tree.tag_configure("custom", font=custom_font)
     joueurs_tries = sorted(Utilisateur.values(), key=lambda joueur: (Victoire[joueur], -Defaite[joueur]), reverse=True)
     for joueur in joueurs_tries:
         nom_joueur = [nom for nom, code in Utilisateur.items() if code == joueur][0]
         nombre_combats = Victoire[joueur] + Defaite[joueur]
         tree.insert("", "end", text=nom_joueur, values=(nombre_combats, Victoire[joueur], Defaite[joueur]) ,tags=("custom",))

     tree.pack(padx=50, pady=50)
     C=Button(f, text="Acceuil", command=ac, font=("Helvetica", 25))
     C.pack(side=LEFT)
     Bou()
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def ac():
    global my_entry
    global ge
    if ge==1:
        Vide(f)
    else:
        chemin_image = "Autre/wel.png"
        image = Image.open(chemin_image)
        photo = ImageTk.PhotoImage(image)
        label_image = Label(f, image=photo)
        label_image.image = photo
        label_image.pack()
    
    a = Label(f, text="Donner votre identifiant, si vous en avez pas merci d'écrire votre pseudo", font=("Helvetica", 25))
    a.pack(pady=10)
    a.pack(side=TOP, anchor=CENTER, expand=YES)

    my_entry = Entry(f,font=("Helvetica", 25))
    my_entry.pack()

    bouton=Button(f, text="Valider", command=afficher,font=("Helvetica", 25))
    bouton.pack(side=TOP, padx=50, pady=10)

    C=Button(f, text="Classement", command=classement, font=("Helvetica", 25))
    C.pack(side=RIGHT)
    Bc()
    f.mainloop()
    ge=0
"""
_______________________________________________________________________________________________________________________________________________________________________
"""
def fene():
    global f
    f = Tk()
    f.attributes('-fullscreen', True)
    maximizer(f)
    ac()
fene()
"""
_________________________________________________________________________________________________________________________________________________________________
"""
def toggle_theme():
    current_theme = f.tk_setPalette()  # Obtient le thème actuel
    if current_theme == "":
        f.tk_setPalette(light_theme)
    else:
        f.tk_setPalette("")  # Utilise le thème par défaut
"""
_______________________________________________________________________________________________________________________________________________________________________
"""




