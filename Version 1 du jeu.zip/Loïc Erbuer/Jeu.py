from combat import*
from pokemon import*

class Jeu:
    def __init__(self,v=0,d=0,c=0):
        self.Lp=[P1,P2,P3,P4,P5,P6,P7,P8,P9,P10,P11,P12,P13,P14,P15,P16,P17,P18,P19,P20,P21,P22,P23,P24,P25,P26,P27,P28,P29,P30,P31,P32,P33,P34,P35,P36,P37,P38,P39,P40,P41,P42,P43,P44,P45,P46,P47,P48,P49,P50]
        self.v=v
        self.d=d
        self.c=c
        
        
        
    def getVictoire(self):
        return self.v
    
    def getDefaite(self):
        return self.d
    
    def getCombat(self):
        return self.c
    
    def setVictoire(self):
        self.v+=1
        
    def setDefaite(self):
        self.d+=1
        
    def downDefaite(self):
        self.d-=self.d
    
    def downVictoire(self):
        self.v-=self.v
        
        
    def setCombat(self):
        self.c+=1
        
    def aleatoire(self):
        from random import randint
        r=randint(1,len(self.Lp))
        return self.Lp[r-1].getNom()
    
    def rencontreP(self):
        from random import randint
        from time import sleep
        self.a=randint(1,len(self.Lp))
        pe=0
        print("_______________________________________________________________________________")
        print("Vous vous baladez dans Valenciennes.")
        sleep(1)
        print("Oh!!!")
        sleep(1)
        print("Il y a un",self.Lp[self.a-1].getNom(),"!!")
        sleep(1)
        reponse=input("Voulez-vous le capturer?\n")
        if reponse=="oui":
            if pe!=1:
                pe=randint(1,3)
                if pe==2:
                    print("Il est sorti de la pokéball")
                    pa=randint(1,2)
                    if pa==1:
                        sleep(1)
                        print("Vous relancez une pokéball")
                        sleep(1)
                        print("Vous l'avez capturé!")
                        pe=0
                        self.p=self.a
                        self.pe=self.a
                        
                    if pa==2:
                        print("Il s'est enfuit")
                        sleep(1)
                        pe=0
                        self.rencontreP()
                if pe==3:
                    print("Il s'est enfuit")
                    pe=0
                    sleep(1)
                    self.rencontreP()
            if pe==1:
                print("Vous l'avez capturé")
                self.p=self.a
                self.pe=self.a
        if reponse=="non":
            print("Vous repartez")
            sleep(1)
            self.rencontreP()
                
    def choixE(self):
        from random import randint
        if self.pe==self.a:
            self.pe=randint(1,len(self.Lp))
            self.choixE()
    
    def Tour(self):
        from time import sleep
        a=Combat(self.Lp[self.p-1],self.Lp[self.pe-1])
        print ("Le pokémon adverse est :",self.Lp[self.pe-1].getNom())
        while self.Lp[self.p-1].getVie()>0 and self.Lp[self.pe-1].getVie()>0:
            print("_______________________________________________________________________________")
            print("Tour :",a.getTour(),"\nA ton tour!")
            sleep(1)
            print("Il te reste:",self.Lp[self.p-1].getVie(),"PV")
            sleep(2)
            a.activationEtatJ()
            print("Il reste ",self.Lp[self.pe-1].getVie(),"PV a ton adversaire")
            sleep(1.5)
            print("Choisie ton attaque:")
            sleep(1)
            a.attaque()
            a.upTour()
            sleep(1)
            self.PAttaque=1
            if self.Lp[self.pe-1].getVie()>0:
                print("_______________________________________________________________________________")
                print("Tour :",a.getTour(),"\nAu tour de l'adversaire!")
                sleep(1)
                a.activationEtatE()
                sleep(1)
                a.attaqueE()
                sleep(1)
                a.upTour()
                self.PAttaqueE=1



