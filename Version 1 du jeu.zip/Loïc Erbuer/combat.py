from pokemon import*

class Combat:
    def __init__(self,joueur="1",ennemi="2",tour=1):
        self.j=joueur
        self.e=ennemi
        self.tour=tour
        self.PAttaque=1
        self.PAttaqueE=1
        
    def getTour(self):
        return self.tour
    
    def getPokemonJoueur (self):
        return self.j.getNom()
    
    def getPokemonEnnemi(self):
        return self.e.getNom()
    
    def upTour(self):
        self.tour+=1
        return self.tour
    
    def activationEtatJ(self):
        from random import randint
        x=randint(1,2)
        if self.j.etat=="Brulure":
            self.j.hp-=10/self.j.defe
            print(self.j.getNom(),"est brulé")
            
        if self.j.etat=="Paralysie":
            print(self.j.getNom(),"est paralysé, il a une chance sur deux d'attaque")
            if x==2:
                self.PAttaque=x
            if x==1:
                self.e.setEtat("Normal")
            
    def activationEtatE(self):
        from random import randint
        x=randint(1,2)
        if self.e.etat=="Brulure":
            print(self.e.getNom(),"est brulé")
            self.e.hp-=5
            return self.e.hp
        if self.e.etat=="Paralysie":
            print(self.e.getNom(),"est paralysé, il a une chance sur deux d'attaquer")
            if x==2:
                self.PAttaqueE=x
            if x==1:
                self.e.setEtat("Normal")
                   
    def attaque(self):
        s=self.j.choix_attaque()
        if self.PAttaque==1:
            if s==1:
                l=self.j.lattaque[0]
                self.e.hp-=l[1]+self.j.at-self.e.defe
                
            elif s==2:
                l=self.j.lattaque[1]
                self.e.hp-=l[1]+self.j.at-self.e.defe
                
            elif s==3:
                l=self.j.lattaque[2]
                self.e.etat=l[1]
                
            elif s==4:
                l=self.j.lattaque[3]
                self.e.hp-=l[1]+self.j.at-self.e.defe
            else:
                self.attaque()
            self.PAttaqueJ=1
        if self.PAttaque==2:
            print( "Paralysé, il ne peut pas attaquer")
            self.PAttaque=1
            self.j.setEtat("Normal")
        
        
    def attaqueE(self):
        from random import randint
        a=randint(1,4)
        if self.PAttaqueE==1:
            if a==1:
                l=self.e.lattaque[0]
                self.j.hp-=l[1]+self.e.at-self.j.defe
                print( "L'attaque lancer par l'énnemi est :", l[0])
            if a==2:
                l=self.e.lattaque[1]
                self.j.hp-=l[1]+self.e.at-self.j.defe
                print( "L'attaque lancer par l'énnemi est :", l[0])
            if a==3:
                l=self.e.lattaque[2]
                self.j.etat=l[1]
                print( "L'attaque lancer par l'énnemi est :", l[0])
                return self.j.etat
            if a==4:
                l=self.e.lattaque[3]
                self.j.hp-=l[1]+self.e.at-self.j.defe
                return ("L'attaque lancer par l'énnemi est :", l[0])
            self.PAttaqueE=1
            
        if self.PAttaqueE==2:
            print( "Paralysé, il ne peut pas attaquer")
            self.PAttaqueE=1
            self.e.setEtat("Normal")
            
A=Combat()           
        
    
    
