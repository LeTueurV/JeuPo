class Pokemon:
    def __init__(self,nom,vie,attaque,defense,liste_attaques,état):
        self.n=nom
        self.hp=vie
        self.at=attaque
        self.defe=defense
        self.lattaque=liste_attaques
        self.etat=état      
    
    def getNom(self):
        return self.n
    
    def getVie(self):
        return round (self.hp,0)
    
    def getAttaque(self):
        return self.at
    
    def getDefense(self):
        return self.defe
    
    def getEtat(self):
        return self.etat
    
    def getListe_attaque(self):
        return self.lattaque[0:len(self.lattaque)]
       
    def setEtat(self,e):
        self.etat=e
        
    def downVie(self,bhp):
        self.hp-=bhp
        
    def downAttaque(self,Batt):
        self.at-=Batt
    
    def downDefense(self,Bdef):
        self.defe-=Bdef
        
    def upVie(self,Uvie):
        self.hp+=Uvie
        
    def upAttaque(self,Uatt):
        self.at+=Uatt
        
    def upDefense(self,Udef):
        self.defe+=Udef
        
    def estMort(self):
        if self.hp!=0:
            return False
        else:
            return True
        
    def choix_attaque(self):
        for i in range(len(self.lattaque)):
            print(i+1,":",self.lattaque[i])
        self.choix=int(input("Quelle est ta reponse?\n"))
        return self.choix
        
        
        
        
        
        
        
        
        
        
P1=Pokemon("Pikachu",110,20,20,[["Charge",20],["éclair",30],["Cage eclair","Paralysie"],["Charge-éclair",35]],"Normal")
P2=Pokemon("Raichu",120,25,30,[["Coup de Boule",20],["éclair impérial",35],["Cage eclair","Paralysie"],["Charge-éclair",25]],"Normal")
P3=Pokemon("Demoloss",110,20,25,[["Griffe",20],["lance-flamme",35],["Feu Follet","Brulure"],["Morsure",25]],"Normal")
P4=Pokemon("Mewtwo",150,35,40,[["Boule psycko",40],["Psy",20],["Intimidation","Paralysie"],["Morsure",25]],"Normal")
P5=Pokemon("Dracaufeu",140,30,25,[["Griffe",20],["lance-flamme",35],["Flamèche","Brulure"],["Morsure",25]],"Normal")
P6=Pokemon("Arcanin",150,20,25,[["Griffe",20],["Croc-feu",30],["Pied Bruleur","Brulure"],["Feu sacré",40]],"Normal")
P7=Pokemon("Mew",170,40,35,[["Piqûre Psy",50],["Piratage de Génome",20],["Voyance","Parlysie"],["Psyko",25]],"Normal")
P8=Pokemon("Ectoplasma",155,30,30,[["Ball'Ombre",45],["Eclat Spectral",25],["Etonnement","Brulure"],["Griffe Ombre",25]],"Normal")
P9=Pokemon("Bullbizare",180,15,40,[["Bullet Seed",30],["Tailblaze",20],["Intimidation","Dodo"],["Lance-Soleil",40]],"Normal")
P10=Pokemon("Leviator",130,35,35,[["Aqua-Jet",35],["Draco-Queue",25],["Intimidation","Paralysie"],["Bulles d'O",35]],"Normal")
P11=Pokemon("Dodrio",110,25,30,[["Bélier",30],["Coupe",35],["Champ-elct","Paralysie"],["Acrobatie",40]],"Normal")
P12=Pokemon("Excelangue",180,15,40,[["Damoclès",40],["Effort",35],["Lèche","Confus"],["Façade",25]],"Normal")
P13=Pokemon("Feuillajou",110,20,25,[["Bullet Seed",30],["Tailblaze",20],["Intimidation","Confus"],["Charge",20]],"Normal")
P14=Pokemon("Fluvetin",90,15,20,[["Canon Floral",20],["Rayon Lune",50],["Fairy Lock","Paralysie"],["Pouvoir Lunaire",40]],"Normal")
P15=Pokemon("Tortank", 150, 30, 35, [["Hydrocanon", 40], ["Cascade", 30], ["Torgnoles", "Dodo"], ["Laser Glace", 35]], "Normal")
P16=    Pokemon("Florizarre", 140, 25, 30, [["Tranch'Herbe", 25], ["Fouet Lianes", 30], ["Poudre Dodo", "Dodo"], ["Lance-Soleil", 35]], "Normal")
P17=     Pokemon("Empiflor", 145, 25, 35, [["Morsure", 25], ["Bélier", 30], ["Bomb", "Poison"], ["Bomb-Beurk", 40]], "Normal")
P18=     Pokemon("Alakazam", 130, 25, 20, [["Psyko", 30], ["Onde Folie", 25], ["Voyance", "Confus"], ["Machination", 35]], "Normal")
P19=     Pokemon("Ronflex", 160, 40, 40, [["Charge", 20], ["Groz'Yeux", 25], ["Roupillon", "Dodo"], ["Léchouille", 30]], "Normal")
P20=     Pokemon("Leveinard", 130, 20, 35, [["Éclat Magique", 25], ["Repos", 35], ["Poudre Dodo", "Dodo"], ["Vœu", 30]], "Normal")
P21=     Pokemon("Flagadoss", 140, 25, 30, [["Éclat Magique", 25], ["Hydrocanon", 40], ["Étincelle", "Paralysie"], ["Amnésie", 35]], "Normal")
P22=     Pokemon("Aeromite", 150, 30, 25, [["Vive-Attaque", 30], ["Tornade", 25], ["Vampirisme", "Poison"], ["Piqué", 35]], "Normal")
P23=     Pokemon("Magicarp", 160, 35, 40, [["Hydrocanon", 40], ["Aqua-Jet", 35], ["Vague à l'âme", "Confus"], ["Lance-Soleil", 30]], "Normal")
P24=     Pokemon("Noadkoko", 140, 25, 30, [["Tranche", 25], ["Psyko", 30], ["Étincelle", "Paralysie"], ["Bomb-Beurk", 35]], "Normal")
P25=     Pokemon("Cloyster", 150, 30, 25, [["Charge", 20], ["Pics Toxik", 35], ["Laser Glace", "Brulure"], ["Repli", 30]], "Normal")
P26=     Pokemon("Exagide", 155, 35, 40, [["Éclat Magique", 30], ["Tranch'Herbe", 35], ["Fermeté", "Confus"], ["Garde Large", 25]], "Normal")
P27=     Pokemon("Nymphali", 140, 25, 30, [["Charge", 20], ["Poudre Dodo", 30], ["Vive-Attaque", "Paralysie"], ["Croissance", 35]], "Normal")
P28=     Pokemon("Amphinobi", 130, 30, 25, [["Cascade", 30], ["Hydrocanon", 40], ["Feinte", "Paralysie"], ["Éboulement", 35]], "Normal")
P29=     Pokemon("Ptyranidur", 160, 35, 40, [["Draco-Queue", 35], ["Mâchouille", 30], ["Jet de Pierre", "Paralysie"], ["Gros Yeux", 25]], "Normal")
P30=     Pokemon("Triopikeur", 140, 25, 30, [["Griffe", 25], ["Tunnelier", 30], ["Coud'Boue", "Confus"], ["Jet-Pierres", 35]], "Normal")
P31=     Pokemon("Papilusion", 130, 20, 25, [["Poudre Dodo", 25], ["Papillodanse", 30], ["Éclat Magique", "Paralysie"], ["Garde Large", 35]], "Normal")
P32=Pokemon("Drattak", 150, 35, 30, [["Lance-Flamme", 35], ["Draco-Météore", 40], ["Ailes d'Acier", "Paralysie"], ["Vive-Attaque", 30]], "Normal")
P33=    Pokemon("Gardevoir", 140, 25, 25, [["Psyko", 30], ["Éclat Magique", 25], ["Choc Psy", "Confus"], ["Vœu", 35]], "Normal")
P34=    Pokemon("Steelix", 160, 30, 40, [["Jet de Pierre", 35], ["Mâchouille", 30], ["Gyroball", "Paralysie"], ["Tomberoche", 25]], "Normal")
P35=    Pokemon("Jirachi", 170, 40, 35, [["Météores", 40], ["Vœu", 35], ["Gyroballe", "Paralysie"], ["Psyko", 30]], "Normal")
P36=    Pokemon("Absol", 140, 30, 25, [["Tranche", 25], ["Ailes d'Acier", 30], ["Morsure", "Paralysie"], ["Vibrobscur", 35]], "Normal")
P37=    Pokemon("Gallame", 150, 35, 30, [["Psyko", 30], ["Lame-Feuille", 35], ["Choc Psy", "Confus"], ["Vœu", 25]], "Normal")
P38=    Pokemon("Pingoléon", 160, 35, 40, [["Hydrocanon", 40], ["Lance-Flamme", 35], ["Cage-Éclair", "Confus"], ["Plaquage", 30]], "Normal")
P39=    Pokemon("Mammochon", 150, 30, 35, [["Lance-Flamme", 35], ["Blizzard", 40], ["Glace Éternelle", "Paralysie"], ["Morsure", 30]], "Normal")
P40=    Pokemon("Carchacrok", 160, 40, 35, [["Crocs Feu", 35], ["Laser Glace", 30], ["Séisme", "Confus"], ["Danse Draco", 25]], "Normal")
P41=    Pokemon("Démétéros", 170, 40, 35, [["Séisme", 40], ["Piqué", 35], ["Lance-Flammes", "Brulure"], ["Mach Punch", 30]], "Normal")
P42=    Pokemon("Boréas", 140, 30, 25, [["Vent Violent", 30], ["Laser Glace", 25], ["Tornade", "Confus"], ["Rapace", 35]], "Normal")
P43=    Pokemon("Noctali", 155, 35, 40, [["Éclat Magique", 30], ["Tranch'Herbe", 35], ["Fermeté", "Confus"], ["Garde Large", 25]], "Normal")
P44=    Pokemon("Goinfrex", 140, 25, 30, [["Charge", 20], ["Poudre Dodo", 30], ["Vive-Attaque", "Paralysie"], ["Croissance", 35]], "Normal")
P45=    Pokemon("Psykokwak", 130, 30, 25, [["Cascade", 30], ["Hydrocanon", 40], ["Feinte", "Confus"], ["Éboulement", 35]], "Normal")
P46=    Pokemon("Lougaroc", 160, 35, 40, [["Draco-Queue", 35], ["Mâchouille", 30], ["Jet de Pierre", "Paralysie"], ["Gros Yeux", 25]], "Normal")
P47=    Pokemon("Topikeur", 140, 25, 30, [["Griffe", 25], ["Tunnelier", 30], ["Coud'Boue", "Confus"], ["Jet-Pierres", 35]], "Normal")
P48=Pokemon("Métamorph", 130, 20, 20, [["Morphing", 30], ["Bélier", 25], ["Cage-Éclair", "Paralysie"], ["Éboulement", 40]], "Normal")
P49=    Pokemon("Meloetta", 150, 30, 30, [["Chant Canon", 25], ["Vent Glace", 35], ["Force Cosmik", "Poison"], ["Choc Mental", 30]], "Normal")
P50=    Pokemon("Rattatac", 140, 35, 25, [["Canon Griffe", 30], ["Lance-Flamme", 40], ["Vibrobscur", "Confus"], ["Chargeur", 25]], "Normal")