from pokemon import*
from combat import*
from Jeu import*
J=Jeu()
#Il faut appeler la fonction : projet()
def projet():
    if len(J.Lp)>0:
        A=J.rencontreP()
        B=J.choixE()
        J.Tour()
        if J.Lp[J.a-1].getVie()<0:
            print("Vous avez perdu")
            J.setDefaite()
            J.setCombat()
            a=input("Voulais vous rejouer?\n 1)Oui \n2)Non \n")
            if a=="non":
                print ("Vous avez fait",J.getCombat(),"combat. Pour",J.getVictoire(),"victoire(s) et ",J.getDefaite()," défaite(s)")
            if a=="oui":
                if J.p<J.pe:
                    del J.Lp[J.p-1]
                    del J.Lp[J.pe-2]
                if J.p>J.pe:
                    del J.Lp[J.p-1]
                    del J.Lp[J.pe-1]
                projet()
        if J.Lp[J.pe-1].getVie()<0:
            print("Vous avez gagnez")
            J.setVictoire()
            J.setCombat()
            a=input("Voulais vous rejouer?\n 1)Oui\n 2)Non\n ")
            a.lower()
            if a=="non":
                print ("Vous avez fait",J.getCombat(),"combat. Pour",J.getVictoire(),"victoire(s) et ",J.getDefaite()," défaite(s)")
            if a=="oui":
                if J.p<J.pe:
                    del J.Lp[J.p-1]
                    del J.Lp[J.pe-2]
                if J.p>J.pe:
                    del J.Lp[J.p-1]
                    del J.Lp[J.pe-1]
                projet()
    if len(J.Lp)==0:
        print("Il n'y a plus de pokémon.\n Impossible de jouer.")
        print ("Vous avez fait",J.getCombat(),"combat. Pour",J.getVictoire(),"victoire(s) et ",J.getDefaite()," défaite(s)")
            

            
